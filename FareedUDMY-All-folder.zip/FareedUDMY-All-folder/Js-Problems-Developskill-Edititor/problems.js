



//Q.1=>PROBLEMS => We work in the company building a smart home thermometer. Our current task is that calculate the temperature of a given day.
 //How is the amplitude in a day?
// Keep in mind that sometimes might occur sensor error?

  // To continue the any problems or projerct of the client ,first we understand  the problems and thbreak the problems into the small chunck chunck 

  // Understand the problems 
// 1- calculate the temperature ?
// 2- what is amplittude?difference between the highest and lowest temperature ?
// 3- What is sensor ?How to the fix sensor error?

// Break the problems into small chunck;

   // fix the erorr;
   // find max and mini temperature by taking the array;
   // subtract the max-temp to mini-temp the amplitude and return it ;
    
  const temperature = [3,4,5,67,-4,-3,-67,-9,'error',353,45,34]
 
  // Take the help from the stakeOverFlow ,how the all javaScript programare are mathimativally  write ;
   function calaAmplitudeTemperaturedeBug(t1,t2){

    const temps = t1.concat(t2);
    console.log(temps);
                 /*  let max = temperature[3];
                  let min = temperature[1]; */

                  let max = 0;
                  let min = 0;


                  for(i =0; i<=temperature.lenght;i++){
                    const curnTemp = temps[i];

                    debugger;
                         if( typeof  curnTemp !== Number)continue;
                         if (temp>0) max=curnTesmp;
                         if (temp<0) min=curnTemp;
                                                }   
        console.log(max,min);
        return max -min
    
                          }

     const amplittude = calaAmplitudeTemperaturedeBug(temperature)
     console.log(amplittude);
     // Now you byhimself try to solve to it in mind amd understand your mind that how it is working 

// How Two Arrays  odf the temperature are added in the functiuioonality ;
       
//Q.2=>PROBLEMS => We work in the company building a smart home thermometer. Our current task is that calculate the temperature of to arrays embeded in thefunction a given day.
 //How is the amplitude in a day?
// Keep in mind that sometimes might occur sensor error?

  //let we first taking the two array of the temperature;

  //here will be the use of the logical operators in conditional statement and method of the math.() fumnction and also use of UNION of method that take more thenm two
  // type date and variable sas we studying in typescript in the PIAIC si Jahzaib. tayyub;

      /* const  morningTemperature = [10,20,30,40,50,60]
      const afternoonTemperature = [25,35,45,55,65,75,85] */



































                                       
