"use strict "
///////////////////////////////////////////////////
///////////////////////////////////////////////////

//BANKIST APP 

// Account Holder  Community Data
const account1 ={
  owner:"Fareed",
  movements :[100,300,-200,4000,950,-100,500,1200],
  interestRate :1.2,
  pin:1122,

};
const account2 ={
  owner:"saqlain",
  movements :[200,400,-400,3000,650,-130,700,13000],
  interestRate :1,
  pin:1111,

};

const account3 ={
  owner:"Fareed",
  movements :[300,500,-300,4000,600,-140,4000,1000],
  interestRate :0.2,
  pin:2222,

};
const account4 ={
  owner:"Fareed",
  movements :[400,500,-600,4000,700,-150,700,100000],
  interestRate :1.2,
  pin:2625,
             };
 const accounts = [account1,account2,account3,account4];

 // Elements 

         const    labelWelcome = document.querySelector('.welcome');
         const  labelData = document.querySelector('.data')
         const  labelBalance = document.querySelector('.balance_value')
         const labelSumIn= document.querySelector('.balance_value--in')
         const labelSumOut= document.querySelector('.balance_value--out')
         const labelSumInterset = document.querySelector('.balance_value--interset')
         const labelTimer = document.querySelector('.timer')
  
        const containerApp = document.querySelector(".app");
        const containerMovements = documentquerySelector(".movements")

        const btnLogin = document.querySelector('login_btn');
        const btnLoan = document.querySelector('form_bt--loan');
        const btnLTransfer = document.querySelector('form_btn--transfer');
        const btnClose= document.querySelector('form_btn--close');
        const btnSort = document.querySelector('btn--sort');
        
        const inputLoginUsername = document.querySelector(".login_input--user");
        const inputLoginPin = document.querySelector(".login_input--pin");
        const inputTransferTo = document.querySelector(".login_input--to");
        const inputTransferAmount = document.querySelector(".form_input--amount");
        const inputLoanAmount = document.querySelector(".form_input--loan-amount");
       const inputCloseUsername= document.querySelector(".form_input--user");
        const inputClosePin = document.querySelector(".form_input--pin");
       

/////////////////////////////////////////////////////
     // LECTURES
      const currencies = new Map([
        ['USD', 'United State Dollor'],
        ['EUR', 'Euro'],
        ['PKR', 'Pakistani Rupees'],
        ['GBP','Pound sterling'],
      ]);
     const movements = [2000,450,600, 7000,-650,340,13000]
    
 





























