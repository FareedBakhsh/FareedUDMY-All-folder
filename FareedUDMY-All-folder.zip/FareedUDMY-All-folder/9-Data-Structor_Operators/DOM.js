
// DOM is a programming interfase for web documents,it act as the interfase for the web applicatiin pages,

//Acess the heading element of html by js;
//DOM is used the acess and manipulated the HTMl elements to attirbutes;

  var heading = document.getElementById('main-heading');

  //change the  text content;

  heading.textContent = "Well_come to the DOM!"

  // Acess the praragraph element ,

  var paragraph = document.getElementById('content');

  // Change the style of the pragraph ; 

        paragraph.style.color = 'blue';


