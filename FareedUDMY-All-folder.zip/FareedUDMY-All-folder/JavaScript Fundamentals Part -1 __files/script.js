let js1 = "FunforFareed";
if (js1 === "FunforFareed");
//alert("js1 is FunforFareed!");
10+ 80+90+50+30+20 -70;
console.log(10+ 80+90+50+30+20 -70);


// This Topic was about the Variable and Its Properties;
//started with symbol,dollor sign , letter 
// it cannot be started by any space ,abd first number 


let firstName1 = "Fareed"
console.log(firstName1);
let firstName1Person;
let myFirsjob ="programmer";
let myCurrentJob = " Teacher";

let job1 ="Programmer";
let job2 = " teacher ";
console.log(myFirsjob);


// Today and this Topic will be Related about the Data Type;

// values ===> object let me {  name = " fareed"};
// OR
// values ==> Primitive  let firstName  = " Fareed" let age = "20yeras"



// Primitive Data Type 




//There are 7 type of the data type that are following 
;

//1 => Number Floating Point Number --> used for decimal and Nummbe r ,eg. let age = "20"

//2  => String : Sequence of the Character --> iuse dfor the text eg. let firstname = " fareed ";

//3 => Boolen : Logic Type that can be true and false ---> used for  taking decisions eg. let fullAge = "true";

// 4 ==> Undefine : Value taken by a variable that is not define ("empty value "); e.g  let children;

//5 ==> Null : Also Mean " empty Value"

// 6 ==> Symbol (ES2015)  : value that is unique and cannot be chjanged;

// 7 ==> BigInt (ES2020): Big and larger  integer than the nummber type can hold;


// if we want  to comment out the single line than we used the the double slashes like //   

// if we want  to comment out the multilpe lines  than we used the the  slashes and steric (*) that is /* hggfrbhjgrgghsvckg */

// All above the features example below
true 
console.log(true);
 
let  JacvascriptISFunforFareed = " true"

console.log(JacvascriptISFunforFareed);

console.log(typeof true);

console.log(typeof  JacvascriptISFunforFareed );

console.log(typeof 23);

console.log(typeof 0);

JacvascriptISFunforFareed  = "yes !"

console.log(typeof  JacvascriptISFunforFareed );

let  year ;
console.log (year);
console.log( typeof year);

let  year1 = 1947 ;
//console.log (year1);
console.log( typeof year1);
console.log(typeof null);


// Today we will discuss the let ,const and Var 

 // let is mostly use  for data type some time use cosnt some time bit var is use in rare 
 // in the fase of the constant , the value of the const is not changed mean remain same 
 // Example ;

 const bitrthdayFareedyear = 2003;// , it const  and never the changed ;


 let age = 30 ;
 age = 35;

 // var is  the old way of the deffine to variable in programming now it become the bad practice  , Mostly in the Current industry of programing let is mostlty used

 var job = "Programmer";
 job = " Teacher "

lastName = "kareem";
console.log(lastName);
 

// Now we discuss about the  All opertors that are used in javacscript ;

// Assignment Operators // Those that are assign the values to variable;
// Math Operators
// Subtraction 
const  faredage = 2023 - 2003;
const  saqlainage =  2023 - 2000;
console.log ( faredage,saqlainage);

// Multiplication 

console.log(faredage *2);


//Division  

console.log(faredage /2);

// use of the square power 

console.log( saqlainage**2);

// Addition ,plus

let firstName = "Fareed"
let lastNmae  = "Bakhsh"

console.log(firstName+''+ lastNmae);

let x= 30+25;
console.log(x);
//Assign Operaotrs
x+= 10 // x = x +10;
x*= 10// x = *10;
x/= 10 // x = x/10;
x++ ,// x -=x +1;increment
x--, // x = x-1;decrement
console.log(x); 


// Comparision Operators;
console.log(faredage >saqlainage); // false
console.log(faredage>=18);// true


const fareedage = saqlainage>=18; // true 


console.log(-1947 < 2023); // true


// Operators Precedence ;


console.log (25-20-5);

let y,z;

y=z =25-20-5;
console.log(y,z);

const averageAge  = (faredage + saqlainage) / 2 ;
console.log(faredage, saqlainage, averageAge);


// ==> Challenges <==

const massFareed = 50 ;
const height     = 2;
const  massSaqlain = 55;
const  heightSaqlain = 3;






























