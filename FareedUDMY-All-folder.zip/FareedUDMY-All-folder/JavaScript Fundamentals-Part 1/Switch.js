// It works like the function in the javaScript , this is a specials case in the javascript;
//we apply th ewwitch statement on the weeken day the programs 

 //Anonymus function like in the type Script;
 /* const day= 'wednesday' */
 /* const day= 'thursday' */
/* const day= 'friday' */
// const day= 'sunday'
const day= 'saturday'
switch(day){
    case 'monday':
    console.warn('This is a software house working day of mine');
    break;

    case 'tuesday':
    console.warn('This is my different serching ythe day of the programming language in office and in the hostem room');
    break;

        case 'wednesday':
         console.warn('This is a client project development Day');
         break;

        case 'thursday':
        console.log('This is a Team training and emerging technology serching day');
        break;

         case 'friday' :
         console.warn('This is special Prayer day for me and the my team')
         break;
         
         case 'saturday':
         case 'sunday':
            console.log('These are Weken_day for me and all my software house working team foe male and female')
            break;

            default:
            console.log('This is valid day')
}

//The above task we can the perform with the conditional statement an of JavaScript;
    
if(day==='monday'){
    console.warn('This is a software house working day of mine');
}

else if(day==='monday'){
    console.warn('This is my different serching ythe day of the programming language in office and in the hostem room');
}

else if(day==='tuesday'){
    console.warn('This is a client project development Day');
}

else if(day==='wednesday' || day === 'thursday'){
    console.log('This is a Team training and emerging technology serching day');
}
else if(day==='friday'){
    console.log('These are Weken_day for me and all my software house working team foe male and female')
    }
    
    else{
    console.log('This is valid day')
}


//Statemwnt  & the expression;
//Here is the Template literalk method is also using where we dynamically add values and get a lonf statement ; 

if(23>9){
     const str ='23 is bigint'
}
let a ="Fareed bakhsh"

console.warn(` He is the ${2024-2003} year old who name is the ${a}`)// This is also using the ananymus method whose threr is no name mean without the name ;

  // Conditional Ternery operators // These are not mostly use and their writting method are  folllowing 
  const age=23;/* 
  age>=18? console.log('I like to drint botal') :console.log('i like to drin water') *///Ternery operators writting method ;

//  const  drink = age >=18 ? 'water' : 'botal';
 
//  console.log(drink);

  let drink2;
  if(age>=18){
    drink2:botal;
  }else{
    drink2:water;
  }
  console.warn(drink2);

  
  











