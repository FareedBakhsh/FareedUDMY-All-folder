let js1 = "FunforFareed";
if (js1 === "FunforFareed");
//alert("js1 is FunforFareed!");
10+ 80+90+50+30+20 -70;
console.log(10+ 80+90+50+30+20 -70);


// This Topic was about the Variable and Its Properties;
//started with symbol,dollor sign , letter 
// it cannot be started by any space ,abd first number 


let firstName1 = "Fareed"
console.log(firstName1);
let firstName1Person;
let myFirsjob ="programmer";
let myCurrentJob = " Teacher";

let job1 ="Programmer";
let job2 = " teacher ";
console.log(myFirsjob);


// Today and this Topic will be Related about the Data Type;

// values ===> object let me {  name = " fareed"};
// OR
// values ==> Primitive  let firstName  = " Fareed" let age = "20yeras"



// Primitive Data Type 




//There are 7 type of the data type that are following 
;

//1 => Number Floating Point Number --> used for decimal and Nummbe r ,eg. let age = "20"

//2  => String : Sequence of the Character --> iuse dfor the text eg. let firstname = " fareed ";

//3 => Boolen : Logic Type that can be true and false ---> used for  taking decisions eg. let fullAge = "true";

// 4 ==> Undefine : Value taken by a variable that is not define ("empty value "); e.g  let children;

//5 ==> Null : Also Mean " empty Value"

// 6 ==> Symbol (ES2015)  : value that is unique and cannot be chjanged;

// 7 ==> BigInt (ES2020): Big and larger  integer than the nummber type can hold;


// if we want  to comment out the single line than we used the the double slashes like //   

// if we want  to comment out the multilpe lines  than we used the the  slashes and steric (*) that is /* hggfrbhjgrgghsvckg */

// All above the features example below
true 
console.log(true);
 
let  JacvascriptISFunforFareed = " true"

console.log(JacvascriptISFunforFareed);

console.log(typeof true);

console.log(typeof  JacvascriptISFunforFareed );

console.log(typeof 23);

console.log(typeof 0);

JacvascriptISFunforFareed  = "yes !"

console.log(typeof  JacvascriptISFunforFareed );

let  year ;
console.log (year);
console.log( typeof year);

let  year1 = 1947 ;
//console.log (year1);
console.log( typeof year1);
console.log(typeof null);


// Today we will discuss the let , and Var 

 // let is mostly use  for data type some time use cosnt some time bit var is use in rare 
 // in the fase of the constant , the value of the const is not changed mean remain same 
 // Example ;

 const bitrthdayFareedyear = 2003;// , it const  and never the changed ;


 let age = 30 ;
 age = 35;

 // var is  the old way of the deffine to variable in programming now it become the bad practice  , Mostly in the Current industry of programing let is mostlty used

 var job = "Programmer";
 job = " Teacher "

lastName = "kareem";
console.log(lastName);
 

// Now we discuss about the  All opertors that are used in javacscript ;

// Assignment Operators // Those that are assign the values to variable;
// Math Operators
// Subtraction 
const  faredage = 2023 - 2003;
const  saqlainage =  2023 - 2000;
console.log ( faredage,saqlainage);

// Multiplication 

console.log(faredage *2);


//Division  

console.log(faredage /2);

// use of the square power 

console.log( saqlainage**2);

// Addition ,plus

let firstName = "Fareed"
let lastNmae  = "Bakhsh"

console.log(firstName+''+ lastNmae);

let x= 30+25;
console.log(x);
//Assign Operaotrs
x+= 10 // x = x +10;
x*= 10// x = *10;
x/= 10 // x = x/10;
x++ ,// x -=x +1;increment
x--, // x = x-1;decrement
console.log(x); 


// Comparision Operators;
console.log(faredage >saqlainage); // false
console.log(faredage>=18);// true


const fareedage = saqlainage>=18; // true 


console.log(-1947 < 2023); // true


// Operators Precedence ;


console.log (25-20-5);

let y,z;

y=z =25-20-5;
console.log(y,z);

const averageAge  = (faredage + saqlainage) / 2 ;
console.log(faredage, saqlainage, averageAge);


// ==> Challenges <==

// Program  Questiuoin Solution
// Q1; 
// Fareed and Saqlain are trying to compare their BMI(Body mass index) that is calculated by using the formula 
  // BMI = mass/ height ** 2= mass (heighg * height).
  // (mass in kg and height in meter)

  //Q2 ; store fareed and saqlain mass and height in variable ;

  // Q3;  Calculate  both their BMIs using the formula ( you can even implement both versions).

  // Q4;   Creat a boolen  variable "saqlainhigherBMI" containing information about whether saqlain has a higher BMI than Fareed.

  // Q5;    Test Data 1 : Fareed weight 50 kg a and 2m tall ,Saqlain  weight 55 kg and 3m tall. 
  
  //  Q5 : Test Data 2 ; Fareed weight 60 kg and 2.5 m is tall , Saqlain weight 65 kg and 3.5 m is tall .
  // Good LUCK ;

const massFareed = 50 ;
const heightFareed     = 2;
const  massSaqlain = 55;
const  heightSaqlain = 3;
const BMIFareed = massFareed/ heightFareed **2 ;
const BMISaqlain = massSaqlain/(heightSaqlain*heightSaqlain);
const  saqlainhigherBMI  = (BMISaqlain > BMIFareed); // Boolen 
console.log(saqlainhigherBMI);
let firstName4 = "Fareed";
const job5 = "teacher";
const  bitrthdayFareedyear4 =  2003 ;

const year4 = 2003;

//const fareed = "I'm" +firstName4 + ' a ' + (yera - bitrthdayFareedyear4) +  'year old' + job5 + "!" ;
console.log("Fareed"); 

// Here is the use of the templete that is shown by the backticks 

const FareedNews  = `I'm ${ firstName4}`
console.log(FareedNews);
firstName4 = 'ghulam'
const fareedNews  = `I'm ${ firstName4}`
console.log(fareedNews);

console.log(` just a regular string... `);

console.log(` string with \n\
               multiple\n\
               line`)

               
               
///.  If and else Statement Taking Decsion and program 

const age1 = 15;
if (age1 > 18){
  console.log(`Fareed can start the driving licence`)
}else {
  const yearleft= age1 -18
  console.log(`Fareed  is too youn .wait another  ${
    yearleft
  }years :`);
}

const day= 'friday'
switch(day){
    case 'monday':
    console.warn('This is a software house working day of mine');
    break;

    case 'tuesday':
    console.warn('This is my different serching ythe day of the programming language in office and in the hostem room');
    break;

        case 'wednesday':
         console.warn('This is a cint project development Day');
         break;

        case 'thursday':
        console.log('This is a Team training and emerging technology serching day');
        break;

         case 'friday' :
         console.warn('This is special Prayer day for me and the my team')
         break;
         
         case 'saturday':
         case 'sunday':
            console.log('These are Weken_day for me and all my software house working team foe male and female')
            break;
            default:
            console.log('This is valid day')
}






















