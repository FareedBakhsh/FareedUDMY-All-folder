
//Default Parammeters;
//The below method is like it that in which we get objetc from the array;
const bookings =[ ];
const createBooking = function (
       
    flightName,
    passangerNumbers =1,
    price = 900 * passangerNumbers ,
){
  const booking = {
    flightName,
    passangerNumbers,
    price,
  }
  console.log(booking);
  bookings.push(booking)
} 
createBooking('Lh123',9,9);
createBooking("Lh123")
createBooking("Lh123")
createBooking("Lh123")
createBooking("Lh123",0,null)
createBooking("Lh123",0,undefined)

//////////////////////////////////////////////////
// Hhow Passing Arguments Works : Valuses Vs. Reference
const flight = 'Lh1234';
const fareed ={
  name : "Fareed Bakhsh",
  passport : '1234567890',
}
const checkIn = function(flightName,passenger){
  flightName = "Lh1234",
  passenger.name = "Mr. " + passenger.name

  if( passenger.passport === '1234567890'){
     //alert(" Checked In")
  }else{
    //alert("Wrong passport")
  }
}
checkIn(flight,fareed);
//console.log(flight);
//console.log(fareed);

// Is same as the  doing;
 //const flightName = flight;
 //const passenger =  fareed;

 const newPassport = function(person){
  person.passport = Math.trunc(Math.random) * 10000000000
 }
newPassport(fareed);
checkIn(flight,fareed);

////////////////////////////////////////////////////////////////////////////
// Functions Accepting Callback Functions

//These below are high  level 
const oneWordForFareed = function (str){
  return str.replace(/ /g,  ' ').toLowerCase( );
}
oneWordForFareed("Hellow ,i love the Holy Quran")

const upperFirstWord = function(str){
  const [first , ...others] = str.split(' ');
  return [ first.toLowerCase( ), ...others].join(' ');
};
//upperFirstWord('i love to the help the other people and work as a welfare of organization');


// Higher-order function
const transformer = function (str,fn){
 console.log(`original string :${str}`);
 console.log(`Transformer stirng ${fn(str)}`);
 console.log(`Transformed by :${fn.name}`);
}
transformer('The JavaScript is the best programming language' , upperFirstWord );
transformer('The JavaScript is the best World programming language' , oneWordForFareed );

// JS uses callbacks all the time
const fareed1 =  function(){
  console.log("👋");
}
document.body.addEventListener("click",fareed1);
['ihsan','Sultan','Adam'].forEach(fareed1);
// In the above function a huge many concept are clearing, the function whose name is
// fareed1    is called by the two methods (1:) 'document.bddy.addEventListener of DOM method 
// second (2); .forEach method

///////////////////////////////////////
// Functions Returning Functions
const greet = function( greeting){
  return function(name){
    console.log(`${greeting} ${name}`)
  }
}
const greeterHeyFareed = greet('HeyFareed');
greeterHeyFareed('Fareed Bakhsh')// This is a best examples of the verloads function 
greeterHeyFareed('M.Saqlain');
greet('Hello Mamo')('You go to madina for the umrah');

 // Challenge

 const greetArr =greeting => name => console.log(`${greeting} ${name}`);
 greetArr("Madani Channel")("Seeing the Fareed Bakhs");

///////////////////////////////////////
const lift = {
  airline : 'AirilinePakistanIslamabad',
  iataCode : '786LH',
  booking :[ ],
  book(flightNum,name){
    console.log(`${name} booked a seat on ${this.airline}flight ${this.iataCode}${flightNum}`)
    //this.booking.push({flight : `${this.iataCode}${flightNum},name`})
  } 

}
lift.book(786,'For fareee');
lift.book(122,'For M. Saqlain');
// above and below codes are co-related with each other;
const PKRrupeesWing = {
  airline :'AirlineKarachiPakistan',
  iataCode :'KARACHI1122',
  bookings :[ ],
}

const book = lift.book;
// Does not work,
// Book(23,'HAzoor Bakhsh');
book.call(PKRrupeesWing,21,'Freed Bakhsh');
console.log(PKRrupeesWing);
book.call(lift,28,'Hafiz M>Imran');
console.log(lift);

//////////////////////////////////////////////////////
///////////////////////////////////////
// Coding Challenge #1
/*

Let's build a simple poll app!

A poll has a question, an array of options from which people can choose, and an array with the
 number of replies for each option. This data is stored in the starter object below.

Here are your tasks:

1. Create a method called 'registerNewAnswer' on the 'poll' object. The method does 2 things:
  1.1. Display a prompt window for the user to input the number of the selected option. The prompt 
  should look like this:
        What is your favourite programming language?
        0: JavaScript
        1: Python
        2: Rust
        3: C++
        (Write option number)
  
  1.2. Based on the input number, update the answers array. For example, if the option is 3, increase 
  the value AT POSITION 3 of the array by 1. Make sure to check if the input is a number and if the 
  
  number makes sense (e.g answer 52 wouldn't make sense, right?)
2. Call this method whenever the user clicks the "Answer poll" button.
3. Create a method 'displayResults' which displays the poll results. The method takes a string as an input (called 
  'type'), which can be either 'string' or 'array'. If type is 'array', simply display the results array as it is,
   using console.log(). This should be the default option. If type is 'string', display a string like 
   "Poll results are 13, 2, 4, 1". 
4. Run the 'displayResults' method at the end of each 'registerNewAnswer' method call.

HINT: Use many of the tools you learned about in this and the last section 😉

BONUS: Use the 'displayResults' method to display the 2 arrays in the test data. Use both the 'array' and the
 'string' option. Do NOT put the arrays in the poll object! So what shoud the this keyword look like in this situation?

BONUS TEST DATA 1: [5, 2, 3]
BONUS TEST DATA 2: [1, 5, 3, 9, 6, 1]

GOOD LUCK 😀
*/
const poll = {
  question :'What is your favourite programming languages.',
  options :['1:JavaScript', '2: Python' ,"3:Java", '4: solidity','5:PHP'],
  // This generates [0,0,0,0]. More in the next Section
  answers : new Array(2).fill(0),
  registerNewAnswer (){
    //get Answer 
    const answer = Number(

      prompt(`${this.question}\n ${this.options.join('\n')}\n(write option number)`
      )
    )
    console.log(answer);
    // Register Answer;
    typeof answer === 'number' && 
    answer < this.answers.length &&
    this.answers[answer]++;
    this.displayResults( );
    this.displayResults('string');
  },


  displayResults(type = 'array'){
    if(type == 'array'){
      console.log(this.answers);
       }else if(type =="string" ) {
        console.log(`Poll results are ${htis.answers.join(', ')}`);
       }
      } ,
    };

document
.querySelector('.poll')
.querySelector('click', poll.registerNewAnswer.bind(poll));

  poll.displayResults.call({ answers : [5,2,3]}, 'strig');
  poll.displayResults.call({ answers : [1,5,3,9,6,1]}, 'strig');
  poll.displayResults.call({ answers : [1,5,3,9,6,1]});
  ///////////////////////////////////////
// Immediately Invoked Function Expressions (IIFE)
const  runOnce = function ( ){
  console.log('This will never run again');
} ;
runOnce ( );
// IIFE

(function ( ){
  console.log('This will never run again');
  const isPrivate = 23;
})( );
//console.log(isPrivate);
(()=> console.log('This will Also nver run again '))( );
{
 // const isPrivate =23;
  var  notPrivate =46;
}
console.log(notPrivate)
/////////////////////////////////////////////
//Closures

const  secureBooking = function ( ){
  let passengerCount = 0 ;
  return function ( ){
    passengerCount++ ;
    console.log(`${passengerCount} passenger`);
  };
};
const  booker = secureBooking ();
booker();
booker();
booker();
console.log(booker);
/////////////////////////////////////////
// More Closure Examples
//Example 1;
let f ;
const g = function ( ){
  const a = 54;
  f = function ( ){
    console.log(a*2);
  }
}
const h = function ( ){
 const b = 99;
   f = function ( ){
    console.log(b *2);

  }
}
g ();
f ();
console.dir(f)

// Re-assigning f function
h();
f();
console.dir(f);

///////////////////////////////////////////////////////////////////////////
// Example 2
const busPassanger = function (n, wait){
  const perGroup = n/3;
  setTimeout(function( ){
    console.log(` We are now boarding all ${n} passanger`);
    console.log(`There  are 3 groups , each with ${perGroup} passenger`);
  }, wait * 1000);
}
const perGroup = 1000;
busPassanger(180,3)

















































  






























































